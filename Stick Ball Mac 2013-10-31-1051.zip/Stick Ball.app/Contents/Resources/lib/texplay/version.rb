module TexPlay
  VERSION = "0.4.3"
end
